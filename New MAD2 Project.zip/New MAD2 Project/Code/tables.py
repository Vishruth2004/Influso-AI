from flask_sqlalchemy import SQLAlchemy
from datetime import datetime, timedelta
from sqlalchemy import desc, and_, or_, func, between

db=SQLAlchemy()

class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    full_name = db.Column(db.String(100), default='Not Set')
    username = db.Column(db.String(50), unique=True, nullable=False)
    email = db.Column(db.String(100), unique=True, nullable=False)
    phone_number = db.Column(db.String(20), default='Not Set')
    password = db.Column(db.String(200), nullable=False)
    role = db.Column(db.String(50), default='user')
    account_created_date = db.Column(db.DateTime, default=datetime.utcnow)
    interested_topics = db.Column(db.Text)
    purpose = db.Column(db.String(100))
    notifications_enabled = db.Column(db.Boolean, default=False)
    verification_code = db.Column(db.String(6))
    last_visit = db.Column(db.DateTime, default=datetime.utcnow)

class Section(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    date_created = db.Column(db.DateTime, default=datetime.utcnow)
    description = db.Column(db.Text)
    books = db.relationship('Book', backref='section', lazy='dynamic')

    def __repr__(self):
        return f'<Section {self.name}>'

class Book(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    content = db.Column(db.Text)
    author = db.Column(db.String(100))
    date_created = db.Column(db.DateTime, default=datetime.utcnow)
    date_issued = db.Column(db.DateTime)
    return_date = db.Column(db.DateTime)
    section_id = db.Column(db.Integer, db.ForeignKey('section.id'), nullable=False)
    price = db.Column(db.Float, nullable=False)

    def __repr__(self):
        return f'<Book {self.name}>'

class Cart(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    book_id = db.Column(db.Integer, db.ForeignKey('book.id'), nullable=False)
    user = db.relationship('User', backref='cart_items')
    book = db.relationship('Book', backref='in_carts')

class BookRequest(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    librarian_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=True)
    book_id = db.Column(db.Integer, db.ForeignKey('book.id'), nullable=False)
    date_requested = db.Column(db.DateTime, default=datetime.utcnow)
    status = db.Column(db.String(20), default='Pending Approval')
    rejection_reason = db.Column(db.String(255), default=None)

    user = db.relationship('User', foreign_keys=[user_id], backref='book_requests')
    librarian = db.relationship('User', foreign_keys=[librarian_id], backref='approved_requests', lazy='joined')
    book = db.relationship('Book', backref='requests')

class Feedback(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_name = db.Column(db.String(20), nullable=False)
    book_name = db.Column(db.String(80), nullable=False)
    rating = db.Column(db.Integer)
    comment = db.Column(db.Text)
    date_given = db.Column(db.DateTime, default=datetime.utcnow)

class Transaction(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    book_id = db.Column(db.Integer, db.ForeignKey('book.id'))
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'))
    transaction_id = db.Column(db.String(100))
    status = db.Column(db.String(50), default='Pending Approval')
    date_created = db.Column(db.DateTime, default=datetime.utcnow)
    # remarks = db.Column(db.String(255), default=None)

    book = db.relationship('Book', backref='transaction')
    user = db.relationship('User', backref='transaction')

    def __repr__(self):
        return f'<Transaction {self.id}>'
