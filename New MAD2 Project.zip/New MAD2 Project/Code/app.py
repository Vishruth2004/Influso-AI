from flask import Flask, redirect, request, render_template, session, url_for, send_from_directory, flash, get_flashed_messages, jsonify, Response, send_file, abort, current_app
from tables import *
from flask_migrate import Migrate
import os
from os.path import join
from collections import Counter, defaultdict
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from email.mime.application import MIMEApplication
from apscheduler.schedulers.background import BackgroundScheduler
from apscheduler.triggers.cron import CronTrigger
from reportlab.lib.pagesizes import letter
from reportlab.pdfgen import canvas
from reportlab.lib import colors
from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import inch
from io import BytesIO, StringIO
import io
from calendar import month_name
from werkzeug.utils import secure_filename
from sqlalchemy.orm import aliased
import random
import string
import logging
import csv
from celery.result import AsyncResult
# from config import app
# from celery_app import make_celery
# from tasks import export_to_csv_task


app = Flask(__name__)

app.secret_key = 'Hello_My_Secert_Key'

static_folder = os.path.abspath('static')
database_file = join(static_folder, 'test.db')
app.config['SQLALCHEMY_DATABASE_URI'] = f'sqlite:///{database_file}'

upload_folder = os.path.abspath('static/uploads/')
app.config['UPLOAD_FOLDER'] = upload_folder 

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

app.config['CELERY_CONFIG'] = {"broker_url": 'redis://localhost:6379/0', "result_backend": 'redis://localhost:6379/0'}

from celery import Celery

def make_celery(app):
    celery = Celery(app.import_name)
    celery.conf.update(app.config['CELERY_CONFIG'])

    class ContextTask(celery.Task):
        def __call__(self, *args, **kwargs):
            with app.app_context():
                return self.run(*args, **kwargs)

    celery.Task = ContextTask
    return celery

# mail = Mail(app)
db.init_app(app)
celery = make_celery(app)
celery.set_default()
app.app_context().push()
migrate = Migrate(app, db)

#--------------------------------------------------Intial Pages---------------------------------------------------#

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    error_message = None
    session['role'] = None
 
    if request.method == 'POST':
        name = request.form['username']
        user_password = request.form['password']

        # Check for regular user login
        user = User.query.filter_by(username=name).first()
    
        if not user:
            error_message = "Username is incorrect"

        elif user.password != user_password:
            error_message = "Password is incorrect"
        else:
            if user.role == 'user':
                session['user_id'] = user.id
                session['username'] = user.username
                session['role'] = 'user'
                user.last_visit = datetime.now()
                db.session.commit()
                return redirect('/user')
            elif user.role == 'librarian':
                session['librarian_id'] = user.id
                session['librarian_name'] = user.username
                session['role'] = 'librarian'
                user.last_visit = datetime.now()
                db.session.commit()
                return redirect('/librarian')

    return render_template('login.html', error_message=error_message)

@app.route('/register', methods=['GET', 'POST'])
def register():
    error_message = None

    if request.method == 'POST':
        full_name = request.form['full_name']
        username = request.form['username']
        password = request.form['password']
        email = request.form['email']
        phone_number = request.form['phone_number']
        purpose = request.form['purpose']
        other_purpose = request.form['other_purpose'] if request.form['purpose'] == 'others' else None

        # Check if the username already exists
        existing_user = User.query.filter_by(username=username).first()

        if existing_user:
            error_message = "Username already exists. Please choose a different username."
        else:
            new_user = User(
                full_name=full_name,
                username=username,
                email=email,
                phone_number=phone_number,
                password=password,
                purpose=purpose if purpose != 'others' else other_purpose
            )
            db.session.add(new_user)
            db.session.commit()
            return redirect('/login')

    return render_template('register.html', error_message=error_message)

def create_librarian():
    librarian = User.query.filter_by(role='librarian').first()
    if not librarian:
        librarian = User(
            username='librarian',
            password='librarian123',  
            role='librarian',
            email='23f1002094@ds.study.iitm.ac.in'
        )
        db.session.add(librarian)
        db.session.commit()

#---------------------------------------------------- Admin ---------------------------------------------------#

@app.route('/manage_user_profiles')
def admin_dashboard():

    if session['role'] != 'librarian':
        flash('Access forbidden!', 'danger')
        return redirect('/user')

    logged_in_users = User.query.filter_by(role='user').all()
    
    return render_template('admin_dashboard.html', logged_in_users=logged_in_users)

@app.route('/admin/disable_user/<int:user_id>', endpoint='disable_user')
def disable_user(user_id):

    if session['role'] != 'librarian':
        flash('Access forbidden!', 'danger')
        return redirect('/user')

    user_entry = User.query.get(user_id)

    if user_entry:
        db.session.delete(user_entry)
        db.session.commit()
        flash('User has been disabled.', 'success')

    return redirect('/manage_user_profiles')
   
#----------------------------------------------- Librarian Pages ---------------------------------------------------#

@app.route('/librarian', methods=['GET', 'POST'])
def librarian_dashboard():

    if session['role'] != 'librarian':
        flash('Access forbidden!', 'danger')
        return redirect('/user')

    sections = Section.query.order_by(desc(Section.date_created)).all()
    librarian_name = session.get('librarian_name', 'Guest Librarian')
    search_query = request.args.get('q', '')

    if request.method == 'POST':
        search_query = request.form.get('q')
        search_type = request.form['search-type']
        search_by = request.form['search-by']

        if search_query:
            results = search_sections(search_query, search_by, search_type)
            return render_template('search_results.html', results=results, search_query=search_query, search_type=search_type)

    return render_template('librarian_dashboard.html', sections=sections, librarian_name=librarian_name)

@app.route('/section/<int:section_id>', methods=['GET'])
def section_details(section_id):

    if session['role'] != 'librarian':
        flash('Access forbidden!', 'danger')
        return redirect('/user')

    section = Section.query.get_or_404(section_id)
    books = section.books.order_by(desc(Book.id)).all()
    return render_template('section_details.html', section=section, books=books)

#------------------------------------------------ CRUD Sections ---------------------------------------------------#

@app.route('/add-section', methods=['GET', 'POST'])
def add_section():

    if session['role'] != 'librarian':
        flash('Access forbidden!', 'danger')
        return redirect('/user')

    if request.method == 'POST':
        name = request.form['name']
        description = request.form['description']
        date_created_str = request.form['date_created']

        date_created = datetime.strptime(date_created_str, '%Y-%m-%dT%H:%M')

        new_section = Section(name=name, description=description, date_created=date_created)
        db.session.add(new_section)
        db.session.commit()
        flash('Section has been added successfully.', 'success')
        return redirect(url_for('librarian_dashboard'))
    return render_template('add_section.html')

@app.route('/update-section/<int:section_id>', methods=['GET', 'POST'])
def update_section(section_id):

    if session['role'] != 'librarian':
        flash('Access forbidden!', 'danger')
        return redirect('/user')

    section = Section.query.get_or_404(section_id)

    if request.method == 'POST':
        section.name = request.form['name']
        section.description = request.form['description']
        date_created_str = request.form['date_created']

        section.date_created = datetime.strptime(date_created_str, '%Y-%m-%dT%H:%M')

        db.session.commit()
        flash('Section has been updated successfully.', 'success')
        return redirect(url_for('librarian_dashboard'))

    return render_template('update_section.html', section=section)

@app.route('/delete-section/<int:section_id>')
def delete_section(section_id):

    if session['role'] != 'librarian':
        flash('Access forbidden!', 'danger')
        return redirect('/user')

    section = Section.query.get_or_404(section_id)
    books = Book.query.filter_by(section_id=section_id).all()
    
    for booku in books:
        # Delete the book
        book_id = booku.id
        carts_with_book = Cart.query.filter_by(book_id=book_id).all()
        for cart in carts_with_book:
            db.session.delete(cart)

        if book_id:
            book = Book.query.get_or_404(book_id)
            book_requests = BookRequest.query.filter_by(book_id=book_id).all()
            for book_request in book_requests:
                db.session.delete(book_request)
            db.session.delete(book)

    db.session.delete(section)
    db.session.commit()
    flash('Section has been deleted successfully.', 'success')

    return redirect(url_for('librarian_dashboard'))
   
#------------------------------------------------- CRUD Books ---------------------------------------------------#

@app.route('/add-book/<int:section_id>', methods=['GET', 'POST'])
def add_book(section_id):
    if session['role'] != 'librarian':
        flash('Access forbidden!', 'danger')
        return redirect('/user')

    section = Section.query.get_or_404(section_id)
    if request.method == 'POST':
        name = request.form['name']
        content_type = request.form['content_type']
        author = request.form['author']
        price = request.form['price']

        if content_type == 'text':
            content = request.form['text_content']
        elif content_type == 'pdf':
            file = request.files.get('file')
            if file and file.filename.endswith('.pdf'):
                filename = secure_filename(file.filename)
                file_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
                print(filename)
                file.save(app.config['UPLOAD_FOLDER'], filename)
                content = app.config['UPLOAD_FOLDER'], filename
                print(content)
            else:
                flash('Invalid File Upload. Use PDF File.', 'danger')
                return render_template('add_book.html', section_id=section_id)
        else:
            flash('Invalid content type.', 'danger')
            return render_template('add_book.html', section_id=section_id)

        new_book = Book(name=name, content=content, author=author, section=section, price=price)
        db.session.add(new_book)
        db.session.commit()
        flash('Book has been added successfully.', 'success')
        return redirect(url_for('section_details', section_id=section_id))

    return render_template('add_book.html', section_id=section_id)


@app.route('/update-book/<int:book_id>', methods=['GET', 'POST'])
def update_book(book_id):

    if session['role'] != 'librarian':
        flash('Access forbidden!', 'danger')
        return redirect('/user')

    book = Book.query.get_or_404(book_id)

    if request.method == 'POST':
        name = request.form['name']
        content_type = request.form['content_type']
        author = request.form['author']
        price = request.form['price']

        if content_type == 'text':
            content = request.form['text_content']
            book.name = name
            book.content = content
            book.author = author
            book.price = price
        elif content_type == 'pdf':
            file = request.files.get('file')
            if file and file.filename.endswith('.pdf'):
                file.save(app.config['UPLOAD_FOLDER'] + file.filename)
                book.name = name
                book.content = app.config['UPLOAD_FOLDER'] + file.filename
                book.author = author
                book.price = price
            else:
                # Handle invalid file upload
                flash('Invalid File Upload. Use PDF File.', 'danger')
                return render_template('update_book.html', book=book)
            
        db.session.commit()
        flash('Book has been updated successfully.', 'success')
        return redirect(url_for('section_details', section_id=book.section.id))

    return render_template('update_book.html', book=book)

@app.route('/delete-book/<int:book_id>')
def delete_book(book_id):

    if session['role'] != 'librarian':
        flash('Access forbidden!', 'danger')
        return redirect('/user')

    book = Book.query.get_or_404(book_id)

    carts_with_book = Cart.query.filter_by(book_id=book_id).all()
    for cart in carts_with_book:
        db.session.delete(cart)
    
    book_requests = BookRequest.query.filter_by(book_id=book_id).all()
    
    for book_request in book_requests:
        db.session.delete(book_request)
    
    section_id = book.section.id  # Store the section ID before deletion
    
    db.session.delete(book)
    db.session.commit()
    flash('Book has been deleted successfully.', 'success')
    return redirect(url_for('section_details', section_id=section_id))

#----------------------------------- Librarian Book Request & Book Reject Reason ---------------------------------------------------#

@app.route('/librarian/book-requests')
def librarian_book_requests():

    if session['role'] != 'librarian':
        flash('Access forbidden!', 'danger')
        return redirect('/user')

    librarian = User.query.get_or_404(session['librarian_id'])
    pending_requests = BookRequest.query.filter(BookRequest.status == 'Pending Approval').order_by(BookRequest.date_requested.desc()).all()
    return render_template('librarian_book_requests.html', librarian=librarian, pending_requests=pending_requests)

@app.route('/librarian/show-book-requests')
def librarian_show_book_requests():

    if session['role'] != 'librarian':
        flash('Access forbidden!', 'danger')
        return redirect('/user')

    librarian_requests = BookRequest.query.all()
    transactions = Transaction.query.order_by(desc(Transaction.id)).all()
    return render_template('librarian_show_book_requests.html', librarian_requests=librarian_requests, transactions=transactions)

@app.route('/librarian/accept-request/<int:request_id>')
def librarian_accept_request(request_id):

    if session['role'] != 'librarian':
        flash('Access forbidden!', 'danger')
        return redirect('/user')

    book_request = BookRequest.query.get_or_404(request_id)

    book_request.status = 'Approved'
    book_request.librarian_id = session.get('librarian_id')
    book_request.book.date_issued = datetime.utcnow()
    book_request.book.return_date = book_request.book.date_issued + timedelta(days=7)

    db.session.commit()
    flash('Book request has been approved.', 'success')

    return redirect(url_for('librarian_book_requests'))

@app.route('/librarian/reject-request/<int:request_id>')
def librarian_reject_request(request_id):

    if session['role'] != 'librarian':
        flash('Access forbidden!', 'danger')
        return redirect('/user')

    book_request = BookRequest.query.get_or_404(request_id)

    book_request.status = 'Rejected'
    book_request.librarian_id = session.get('librarian_id')

    db.session.commit()

    return redirect(url_for('librarian_reject_request_with_reason', request_id=request_id))

@app.route('/librarian/revoke-access/<int:request_id>')
def librarian_revoke_access(request_id):

    if session['role'] != 'librarian':
        flash('Access forbidden!', 'danger')
        return redirect('/user')

    book_request = BookRequest.query.get_or_404(request_id)

    book_request.status = 'Access Removed'
    book_request.book.return_date = datetime.now()
    db.session.commit()

    return redirect(url_for('librarian_reject_request_with_reason', request_id=request_id))

@app.route('/librarian/reject-request-with-reason/<int:request_id>', methods=['GET', 'POST'])
def librarian_reject_request_with_reason(request_id):

    if session['role'] != 'librarian':
        flash('Access forbidden!', 'danger')
        return redirect('/user')

    book_request = BookRequest.query.get_or_404(request_id)

    if request.method == 'POST':
        rejection_reason = request.form.get('rejection_reason')
        
        if book_request.status == 'Rejected' and rejection_reason is not None:
            book_request.rejection_reason = rejection_reason
            db.session.commit()
            flash('Book request has been rejected.', 'success')
            return redirect(url_for('librarian_book_requests'))

        if book_request.status == 'Access Removed' and rejection_reason is not None:
            book_request.rejection_reason = rejection_reason
            db.session.commit()
            flash('Access to the book has been revoked.', 'success')
            return redirect(url_for('librarian_show_book_requests'))


    return render_template('librarian_reject_reason.html', request_id=request_id)

@app.route('/librarian/view-rejection-reason/<int:request_id>')
def view_rejection_reason(request_id):

    if session['role'] != 'librarian':
        flash('Access forbidden!', 'danger')
        return redirect('/user')

    book_request = BookRequest.query.get_or_404(request_id)
    return render_template('librarian_view_rejection_reason.html', reason=book_request, GoBack = 0)
   
#--------------------------------------------------- User pages ---------------------------------------------------#

@app.route('/user', methods=['GET', 'POST'])
def user_dashboard():
    if session['role'] != 'user':
        flash('Access forbidden!', 'danger')
        return redirect('/librarian')

    user = User.query.get(session['user_id'])
    
    due()
    sections = Section.query.order_by(desc(Section.date_created)).all()
    user_name = session.get('username', 'Guest User')
    search_query = request.args.get('q', '')

    if request.method == 'POST':
        search_query = request.form.get('q')
        search_type = request.form['search-type']
        search_by = request.form['search-by']

        if search_query:
            results = search_sections(search_query, search_by, search_type)
            return render_template('user_search_results.html', results=results, search_query=search_query, search_type=search_type, search_by=search_by)

    return render_template('user_dashboard.html', sections=sections, user_name=user_name)

def due():
    # Get all approved books
    overdue_requests = BookRequest.query.filter(BookRequest.status == 'Approved').all()

    for request in overdue_requests:
        if request.book.return_date < datetime.now():
            # Revoke access for overdue books
            request.status = 'Due Date Passed'
            db.session.commit()

@app.route('/user/section/<int:section_id>', methods=['GET'])
def user_section_details(section_id):

    if session['role'] != 'user':
        flash('Access forbidden!', 'danger')
        return redirect('/librarian')

    section = Section.query.get_or_404(section_id)
    books = section.books.order_by(desc(Book.id)).all()
    return render_template('user_section_details.html', section=section, books=books)
   
#------------------------------------------------------ Cart ---------------------------------------------------#

@app.route('/user/cart')
def cart():

    if session['role'] != 'user':
        flash('Access forbidden!', 'danger')
        return redirect('/librarian')

    user = User.query.get_or_404(session['user_id'])
    return render_template('cart.html', user=user)

@app.route('/user/add-to-cart/<int:book_id>')
def user_add_to_cart(book_id):

    if session['role'] != 'user':
        flash('Access forbidden!', 'danger')
        return redirect('/librarian')

    book = Book.query.get_or_404(book_id)
    user = User.query.get_or_404(session['user_id'])

    if book not in user.cart_items:
        cart_item = Cart(user=user, book=book)
        db.session.add(cart_item)
        db.session.commit()
        flash('Book has been added to your cart.', 'success')

    return redirect(url_for('user_section_details', section_id=book.section.id))

@app.route('/user/search-add-to-cart/<int:book_id>')
def search_user_add_to_cart(book_id):

    if session['role'] != 'user':
        flash('Access forbidden!', 'danger')
        return redirect('/librarian')

    book = Book.query.get_or_404(book_id)
    user = User.query.get_or_404(session['user_id'])

    search_query = request.args.get('search_query')
    search_by = request.args.get('search_by')
    search_type = request.args.get('search_type')

    if book not in user.cart_items:
        cart_item = Cart(user=user, book=book)
        db.session.add(cart_item)
        db.session.commit()
        flash('Book has been added to your cart.', 'success')
    results = search_sections(search_query, search_by, search_type)
    return render_template('user_search_results.html', results=results, search_query=search_query, search_type=search_type, search_by=search_by)

@app.route('/user/remove-from-cart/<int:cart_item_id>')
def user_remove_from_cart(cart_item_id):

    if session['role'] != 'user':
        flash('Access forbidden!', 'danger')
        return redirect('/librarian')

    cart_item = Cart.query.get_or_404(cart_item_id)
    
    db.session.delete(cart_item)
    db.session.commit()

    return redirect(url_for('cart'))

#--------------------------------------- User Book Request & Book Reject Reason ---------------------------------------------------#

@app.route('/user/book-requests')
def user_book_requests():

    if session['role'] != 'user':
        flash('Access forbidden!', 'danger')
        return redirect('/librarian')

    user = User.query.get_or_404(session['user_id'])
    user_requests = BookRequest.query.filter_by(user_id=user.id).all()

    return render_template('user_book_requests.html', user=user, user_requests=user_requests)

@app.route('/user/request-book/<int:book_id>')
def user_request_book(book_id):

    if session['role'] != 'user':
        flash('Access forbidden!', 'danger')
        return redirect('/librarian')

    user = User.query.get_or_404(session['user_id'])
    book = Book.query.get_or_404(book_id)

    # Check if user has reached the maximum limit of 5 requests
    if BookRequest.query.filter(and_(BookRequest.user_id == user.id, BookRequest.status.in_(['Pending Approval', 'Approved']))).count() >= 5:
        flash('You have already requested the maximum number of books. Please return some books to request more.', 'danger')
        return redirect(url_for('cart'))

    existing_request = BookRequest.query.filter_by(user_id=user.id, book_id=book.id).first()

    if (not existing_request) or (existing_request.status != "Approved"):
        new_request = BookRequest(user=user, book=book)
        db.session.add(new_request)
        db.session.commit()
        flash('Your book request has been sent.', 'success')

        # Remove the book from the user's cart after creating the request
        cart_item = Cart.query.filter_by(user=user, book=book).first()
        if cart_item:
            db.session.delete(cart_item)
            db.session.commit()
        return redirect(url_for('user_book_requests'))
    else:
        flash('This book has already been requested. Check your "Book Requests" tab to know the Status.', 'danger')
    
    return redirect(url_for('user_section_details', section_id=book.section.id))

@app.route('/user/unsend-request/<int:request_id>')
def user_unsend_request(request_id):

    if session['role'] != 'user':
        flash('Access forbidden!', 'danger')
        return redirect('/librarian')

    user_request = BookRequest.query.get_or_404(request_id)

    if user_request.status == 'Pending Approval':
        db.session.delete(user_request)
        db.session.commit()
        flash('Your book request has been canceled.', 'success')

    return redirect(url_for('user_book_requests'))

@app.route('/user/return-book/<int:request_id>')
def user_return_book(request_id):

    if session['role'] != 'user':
        flash('Access forbidden!', 'danger')
        return redirect('/librarian')

    user_request = BookRequest.query.get_or_404(request_id)

    user_request.status = 'User Returned'
    user_request.book.return_date = datetime.now()
    db.session.commit()
    flash('Book has been returned successfully.', 'success')

    return redirect(url_for('user_book_requests'))

@app.route('/user/view-rejection-reason/<int:request_id>')
def user_view_rejection_reason(request_id):

    if session['role'] != 'user':
        flash('Access forbidden!', 'danger')
        return redirect('/librarian')

    book_request = BookRequest.query.get_or_404(request_id)
    return render_template('librarian_view_rejection_reason.html', reason=book_request, GoBack = 1)

@app.route('/user/view-book/<int:book_id>')
def view_book(book_id):
    if session['role'] != 'user':
        flash('Access forbidden!', 'danger')
        return redirect('/librarian')

    book = Book.query.get_or_404(book_id)
    
    if book.content.endswith('.pdf'):
        file_url = url_for('serve_pdf', book_id=book_id)
    else:
        file_url = None

    return render_template('user_view_book.html', book=book, file_url=file_url)

@app.route('/serve-pdf/<int:book_id>')
def serve_pdf(book_id):
    if session['role'] != 'user':
        flash('Access forbidden!', 'danger')
        return redirect('/librarian')

    book = Book.query.get_or_404(book_id)
    if not book.content or not os.path.exists(book.content):
        abort(404)  # File not found

    return send_file(book.content, mimetype='application/pdf')
   
#----------------------------------------------------- Feedback ---------------------------------------------------#

@app.route('/user/give-feedback/<int:request_id>', methods=['GET', 'POST'])
def user_give_feedback(request_id):

    if session['role'] != 'user':
        flash('Access forbidden!', 'danger')
        return redirect('/librarian')
    
    user_request = BookRequest.query.get_or_404(request_id)
    user_feedback = Feedback.query.filter_by(user_name=user_request.user.username, book_name=user_request.book.name).order_by(desc(Feedback.date_given)).first()
    feedbacks = Feedback.query.filter_by(book_name=user_request.book.name).all()

    if request.method == 'POST':
        rating = int(request.form['rating'])
        comment = request.form['comment']
        new_feedback = Feedback(user_name=user_request.user.username, book_name=user_request.book.name, rating=rating, comment=comment)
        db.session.add(new_feedback)
        db.session.commit()
        flash('Thank you for your feedback.', 'success')
        
        user_request = BookRequest.query.get_or_404(request_id)
        user_feedback = Feedback.query.filter_by(user_name=user_request.user.username, book_name=user_request.book.name).order_by(desc(Feedback.date_given)).first()
        feedbacks = Feedback.query.filter_by(book_name=user_request.book.name).all()
        

        return render_template('give_feedback.html', user_request=user_request, user_feedback=user_feedback, feedbacks=feedbacks, overall_ratings_count=calculate_overall_ratings_count(feedbacks), average_rating=calculate_average_rating(feedbacks), GoBack=1)

    return render_template('give_feedback.html', user_request=user_request, user_feedback=user_feedback, feedbacks=feedbacks, overall_ratings_count=calculate_overall_ratings_count(feedbacks), average_rating=calculate_average_rating(feedbacks), GoBack=1)

def calculate_average_rating(feedbacks):
    if not feedbacks:
        return 0.0

    total_ratings = sum(feedback.rating for feedback in feedbacks)
    return total_ratings / len(feedbacks)

def calculate_overall_ratings_count(feedbacks):
    ratings_count = {1: 0, 2: 0, 3: 0, 4: 0, 5: 0}
    for feedback in feedbacks:
        ratings_count[feedback.rating] += 1
    return ratings_count

@app.route('/user/view-feedback/<int:book_id>')
def user_view_feedback(book_id):

    if session['role'] != 'user':
        flash('Access forbidden!', 'danger')
        return redirect('/librarian')

    book = Book.query.get(book_id)
    user_request = BookRequest.query.filter_by(user_id=session['user_id'], book_id=book_id).first()
    user_feedback = Feedback.query.filter_by(user_name=session['username'], book_name=book.name).order_by(desc(Feedback.date_given)).first()
    feedbacks = Feedback.query.filter_by(book_name=book.name).all()

    return render_template('give_feedback.html', book = book, overall_ratings_count=calculate_overall_ratings_count(feedbacks), user_request=user_request, user_feedback=user_feedback, feedbacks=feedbacks, average_rating=calculate_average_rating(feedbacks), GoBack=0)

#------------------------------------------------------ Search ---------------------------------------------------#

def search_sections(search_query, search_by, search_type):

    if search_type == 'sections':
        if search_by == 'name':
            section_results = search_items(search_query, Section, 'name')
            return section_results
        elif search_by == 'description':
            section_results = search_items(search_query, Section, 'description')
            return section_results
        else:
            raise ValueError("Invalid search_by parameter")
        
    elif search_type == 'books':
        if search_by == 'book_name':
            section_results = search_items(search_query, Book, 'name')
            return section_results
        elif search_by == 'author':
            section_results = search_items(search_query, Book, 'author')
            return section_results
        elif search_by == 'section_name':
            section_results = search_items(search_query, Section, 'name')
            book_results = []
            for section in section_results:
                books = section.books.all()
                book_results.extend(books)
            return book_results
        else:
            raise ValueError("Invalid search_by parameter")
    else:
        raise ValueError("Invalid search_type parameter")

def search_items(search_query, Model, str_param):
    terms = search_query.split()
    items = Model.query
    items_and = items.filter(and_(*[getattr(Model, str_param).ilike(f'%{term}%') for term in terms]))
    items_or = items.filter(or_(*[getattr(Model, str_param).ilike(f'%{term}%') for term in terms]))
    items_combine = items_and.union(items_or)
    item_results = []
    for term in terms:
        items_startswith = items_combine.filter(getattr(Model, str_param).ilike(f'{term}%')).all()
        items_anywhere = items_combine.filter(getattr(Model, str_param).ilike(f'%{term}%')).all()
        item_results.extend(items_startswith)
        item_results.extend(items_anywhere)
    item_results = list(set(item_results))

    def custom_sort(item):
        relevance = sum(term.lower() in getattr(item, str_param).lower() for term in terms)  # Number of terms in the item attribute
        term_positions = [getattr(item, str_param).lower().find(term.lower()) for term in terms]  # Positions of terms in the item attribute
        return (-relevance, min(term_positions))  # Sort by relevance and then by the minimum term position
    
    # Sort items using the custom sorting function
    item_results.sort(key=custom_sort)

    return item_results

#-------------------------------------------------- User Profile  ---------------------------------------------------#

@app.route('/profile')
def profile():

    if session.get('role') != 'user':
        flash('Access forbidden!', 'danger')
        return redirect('/user')

    user_id = session['user_id']
    user = User.query.get(user_id)

    # Book statistics
    books_requested = BookRequest.query.filter_by(user_id=user_id, status='Pending Approval').count()
    books_read = BookRequest.query.filter_by(user_id=user_id, status='User Returned').count()
    books_issued = BookRequest.query.filter(BookRequest.user_id==user_id, BookRequest.status.in_(['Approved', 'Rejected', 'User Returned', 'Access Removed', 'Due Date Passed'])).all()
    current_borrowing_limit = 5 - books_requested

    # Feedback statistics
    feedbacks = Feedback.query.filter_by(user_name=user.username).all()
    total_books_reviewed = len(feedbacks)
    stars_distribution = {i: 0 for i in range(1, 6)}
    total_comments = 0

    for feedback in feedbacks:
        stars_distribution[feedback.rating] += 1
        if feedback.comment:
            total_comments += 1

    profile_data = {
        'username': user.username,
        'fullName': user.full_name,
        'email': user.email,
        'phoneNumber': user.phone_number,
        'accountCreatedDate': user.account_created_date.strftime('%Y-%m-%d'),
        'borrowingLimit': current_borrowing_limit,
        'booksRequested': books_requested,
        'booksRead': books_read,
        'booksIssued': [{'id': books.id, 'name': books.book.name} for books in books_issued],
        'interestedTopics': user.interested_topics.split(',') if user.interested_topics else [],
        'reviewsGiven': [{'bookName': feedback.book_name, 'rating': feedback.rating, 'comment': feedback.comment} for feedback in feedbacks],
        'totalBooksReviewed': total_books_reviewed,
        'starsDistribution': stars_distribution,
        'totalComments': total_comments,
        'purpose': user.purpose,
        'notificationsEnabled': False
    }

    return render_template('profile.html', profile=profile_data)

@app.route('/update_profile', methods=['POST'])
def update_profile():

    if session['role'] != 'user':
        flash('Access forbidden!', 'danger')
        return redirect('/librarian')

    user_id = session['user_id']
    user = User.query.get(user_id)
    
    data = request.json
    user.full_name = data.get('fullName', user.full_name)
    user.email = data.get('email', user.email)
    user.phone_number = data.get('phoneNumber', user.phone_number)
    user.purpose = data.get('purpose', user.purpose)

    user.notifications_enabled = False
    
    db.session.commit()
    return jsonify({"status": "success"})

@app.route('/add_interests', methods=['POST'])
def add_interests():

    if session['role'] != 'user':
        flash('Access forbidden!', 'danger')
        return redirect('/librarian')

    user_id = session['user_id']
    user = User.query.get(user_id)
    
    new_interest = request.json.get('newInterests')
    if new_interest:
        current_interests = user.interested_topics.split(',') if user.interested_topics else []
        if new_interest not in current_interests:
            current_interests.append(new_interest)
            user.interested_topics = ','.join(current_interests)
            db.session.commit()
    return jsonify({"status": "success"})

@app.route('/remove_interests', methods=['POST'])
def remove_interests():

    if session['role'] != 'user':
        flash('Access forbidden!', 'danger')
        return redirect('/librarian')

    user_id = session['user_id']
    user = User.query.get(user_id)
    
    interest = request.json.get('interest')
    if interest:
        current_interests = user.interested_topics.split(',') if user.interested_topics else []
        if interest in current_interests:
            current_interests.remove(interest)
            user.interested_topics = ','.join(current_interests)
            db.session.commit()
    return jsonify({"status": "success"})

#-------------------------------------------- Librarian Statistics  ----------------------------------------------#

@app.route('/statistics/section_wise_distribution')
def section_wise_distribution():

    if session['role'] != 'librarian':
        flash('Access forbidden!', 'danger')
        return redirect('/user')

    distribution = db.session.query(Section.name, func.count(Book.id)).\
        join(Book, Section.id == Book.section_id).\
        group_by(Section.id).limit(10).all()
    
    labels = [item[0] for item in distribution]
    values = [item[1] for item in distribution]
    
    total_books = sum(values)
    max_section = max(distribution, key=lambda x: x[1])
    min_section = min(distribution, key=lambda x: x[1])

    if not distribution:
        return jsonify({
        'labels': labels,
        'data': values,
        'keyStats': ['Could not compute Statistics. No Sections and Books are added.']
    })
    
    key_stats = [
        f"Total Books: {total_books}",
        f"Section with Most Books: {max_section[0]} ({max_section[1]} books)",
        f"Section with Least Books: {min_section[0]} ({min_section[1]} books)",
        f"Number of Sections: {len(distribution)}"
    ]
    
    return jsonify({
        'labels': labels,
        'data': values,
        'keyStats': key_stats
    })

@app.route('/statistics/new_books_over_days')
def new_books_over_time():

    if session['role'] != 'librarian':
        flash('Access forbidden!', 'danger')
        return redirect('/user')

    date_range = datetime.now() - timedelta(days=10)
    
    # Query to get the new books created within the last 10 days
    new_books = db.session.query(
        func.date(Book.date_created),
        func.count(Book.id)
    ) \
    .filter(Book.date_created >= date_range) \
    .group_by(func.date(Book.date_created)) \
    .order_by(func.date(Book.date_created)) \
    .all()
    
    if not new_books:
        return jsonify({
            'labels': [],
            'data': [],
            'keyStats': ['Could not compute Statistics. No books are added.']
        })
    
    # Extract labels and values
    labels = [item[0] for item in new_books]  # Date only
    values = [item[1] for item in new_books]

    # Calculate total books, average books per day, and day with most books
    total_books = sum(values)
    avg_books_per_day = total_books / len(new_books)
    max_books_day = max(new_books, key=lambda x: x[1])
    
    key_stats = [
        f"Total Books Added: {total_books}",
        f"Average Books Added per Day: {avg_books_per_day:.2f}",
        f"Day with Most Books Added: {max_books_day[0]} ({max_books_day[1]} books)"
    ]
    
    return jsonify({
        'labels': labels,
        'data': values,
        'keyStats': key_stats
    })

@app.route('/statistics/books_requested_by_section')
def books_requested_by_section():

    if session['role'] != 'librarian':
        flash('Access forbidden!', 'danger')
        return redirect('/user')

    data = db.session.query(
        Section.name,
        func.count(BookRequest.id)
    ).join(Book, Section.id == Book.section_id).\
    join(BookRequest, Book.id == BookRequest.book_id).\
    group_by(Section.name).limit(10).all()
    
    labels = [row[0] for row in data]
    values = [row[1] for row in data]

    if not data:
        return jsonify({
        'labels': labels,
        'data': values,
        'keyStats': ['Could not compute Statistics. No User has Requested any Books from any Sections.']
    })
    
    total_requests = sum(values)
    max_section = max(data, key=lambda x: x[1])
    min_section = min(data, key=lambda x: x[1])
    
    key_stats = [
        f"Total Requests: {total_requests}",
        f"Most Requested Section: {max_section[0]} ({max_section[1]} requests)",
        f"Least Requested Section: {min_section[0]} ({min_section[1]} requests)",
        f"Average Requests per Section: {total_requests / len(data):.2f}"
    ]
    
    return jsonify({'labels': labels, 'data': values, 'keyStats': key_stats})

@app.route('/statistics/most_requested_books')
def most_requested_books():

    if session['role'] != 'librarian':
        flash('Access forbidden!', 'danger')
        return redirect('/user')

    data = db.session.query(
        Book.name,
        func.count(BookRequest.id)
    ).join(BookRequest, Book.id == BookRequest.book_id).\
    group_by(Book.name).\
    order_by(desc(func.count(BookRequest.id))).\
    limit(10).all()
    
    labels = [row[0] for row in data]
    values = [row[1] for row in data]
    
    total_requests = sum(values)

    if not data:
        return jsonify({
        'labels': labels,
        'data': values,
        'keyStats': ['Could not compute Statistics. No User has Requested any Books.']
    })
    
    key_stats = [
        f"Total Requests for Top 10 Books: {total_requests}",
        f"Most Requested Book: {labels[0]} ({values[0]} requests)",
        f"Average Requests for Top 10 Books: {total_requests / 5:.2f}"
    ]
    
    return jsonify({'labels': labels, 'data': values, 'keyStats': key_stats})

@app.route('/statistics/star_ratings_distribution')
def star_ratings_distribution():

    if session['role'] != 'librarian':
        flash('Access forbidden!', 'danger')
        return redirect('/user')

    data = db.session.query(
        Feedback.rating,
        func.count(Feedback.id)
    ).group_by(Feedback.rating).all()
    
    labels = [f'{row[0]} Stars' for row in data]
    values = [row[1] for row in data]

    if not data:
        return jsonify({
        'labels': labels,
        'data': values,
        'keyStats': ['Could not compute Statistics. No User has Rated any book.']
    })
    
    total_ratings = sum(values)
    avg_rating = sum(row[0] * row[1] for row in data) / total_ratings
    
    key_stats = [
        f"Total Ratings: {total_ratings}",
        f"Average Rating: {avg_rating:.2f} Stars",
        f"Most Common Rating: {labels[values.index(max(values))]} ({max(values)} ratings)"
    ]
    
    return jsonify({'labels': labels, 'data': values, 'keyStats': key_stats})


@app.route('/statistics/books_with_high_ratings')
def books_with_high_ratings():

    if session['role'] != 'librarian':
        flash('Access forbidden!', 'danger')
        return redirect('/user')

    # Query to get the books with average rating and number of ratings
    data = db.session.query(
        Book.name,
        func.avg(Feedback.rating).label('average_rating'),
        func.count(Feedback.id).label('rating_count')
    ).join(Feedback, Feedback.book_name == Book.name).\
    group_by(Book.name).\
    having(func.avg(Feedback.rating) >= 4).\
    order_by(desc('average_rating')).\
    limit(10).all()
    
    labels = [row[0] for row in data]
    values = [float(row[1]) for row in data]

    if not data:
        return jsonify({
        'labels': labels,
        'data': values,
        'keyStats': ['Could not compute Statistics. No User has Rated any book.']
    })

    # Determine the highest-rated book by considering the number of ratings
    highest_rated_books = [row for row in data if row[1] == values[0]]
    highest_rated_book = max(highest_rated_books, key=lambda x: x[2])

    key_stats = [
        f"Total Number of High-Rated Books: {len(data)}",
        f"Highest Rated Book: {highest_rated_book[0]} ({highest_rated_book[1]:.2f} stars, {highest_rated_book[2]} ratings)",
        f"Average Rating of Top 10 Books: {sum(values) / len(values):.2f} stars"
    ]
    
    return jsonify({'labels': labels, 'data': values, 'keyStats': key_stats})

@app.route('/statistics/user_registrations_over_days')
def user_registrations_over_time():

    if session['role'] != 'librarian':
        flash('Access forbidden!', 'danger')
        return redirect('/user')

    ten_days_ago = datetime.now() - timedelta(days=10)
    data = db.session.query(
        func.date(User.account_created_date),
        func.time(User.account_created_date),
        func.count(User.id)
    ).filter(
        User.role != 'librarian',
        User.account_created_date >= ten_days_ago
    ).group_by(func.date(User.account_created_date), func.time(User.account_created_date)).order_by(func.date(User.account_created_date), func.time(User.account_created_date)).all()

    if not data:
        return jsonify({
            'labels': [],
            'data': [],
            'keyStats': ['Could not compute Statistics. No User has Registered.']
        })

    date_counts = defaultdict(int)
    for item in data:
        date = item[0]  # Extract the date part
        count = item[2]  # Extract the registration count
        date_counts[date] += count  # Sum the counts for each date

    # Extract dates and counts
    dates = list(date_counts.keys())
    daily_counts = list(date_counts.values())

    total_users = sum(daily_counts)
    avg_users_per_day = total_users / len(dates) if dates else 0

    max_registrations_date = max(date_counts.items(), key=lambda x: x[1])
    max_date = max_registrations_date[0]
    max_count = max_registrations_date[1]

    key_stats = [
        f"Total Users: {total_users}",
        f"Average Registrations per Day: {avg_users_per_day:.2f}",
        f"Day with Most Registrations: {max_date} ({max_count} users)"
    ]

    return jsonify({
        'labels': dates,
        'data': daily_counts,
        'keyStats': key_stats
    })

@app.route('/statistics/top_genres_liked_by_users')
def top_genres_liked_by_users():

    if session['role'] != 'librarian':
        flash('Access forbidden!', 'danger')
        return redirect('/user')

    users = db.session.query(User.interested_topics).all()
    
    genre_counter = Counter()
    
    for user in users:
        if user.interested_topics:
            genres = user.interested_topics.split(',')
            for genre in genres:
                genre_counter[genre.strip()] += 1

    top_genres = genre_counter.most_common(10)

    labels = [item[0] for item in top_genres]
    values = [item[1] for item in top_genres]

    total_interests = sum(values)

    # Find the maximum user count
    max_user_count = max(values, default=0)

    # Get all genres with the maximum user count
    most_popular_genres = [item for item in top_genres if item[1] == max_user_count]

    if not top_genres:
        return jsonify({
        'labels': labels,
        'data': values,
        'keyStats': ['Could not compute Statistics. No User has added Interested Genres.']
    })

    key_stats = [
        f"Total Genre Interests: {total_interests}",
        f"Most Popular Genres: {', '.join(f'{genre[0]} ({genre[1]} users)' for genre in most_popular_genres)}",
        f"Average Users per Top Genre: {total_interests / len(top_genres):.2f}"
    ]

    return jsonify({'labels': labels, 'data': values, 'keyStats': key_stats})

@app.route('/statistics/user_demographics')
def user_demographics():

    if session['role'] != 'librarian':
        flash('Access forbidden!', 'danger')
        return redirect('/user')

    data = db.session.query(
        User.purpose,
        func.count(User.id).label('count')
    ).filter(User.role != 'librarian').group_by(User.purpose).all()

    labels = [item[0] for item in data]
    values = [item[1] for item in data]

    total_users = sum(values)
    
    if not data:
        return jsonify({
        'labels': labels,
        'data': values,
        'keyStats': ['Could not compute Statistics. No User has Registered.']
    })

    key_stats = [
        f"Total Users: {total_users}",
        f"Most Common Purpose: {labels[values.index(max(values))]} ({max(values)} users)",
        f"Number of Different Purpose: {len(data)}"
    ]

    return jsonify({'labels': labels, 'data': values, 'keyStats': key_stats})

@app.route('/statistics/top_users_by_books_borrowed')
def top_users_by_books_borrowed():

    if session['role'] != 'librarian':
        flash('Access forbidden!', 'danger')
        return redirect('/user')

    data = db.session.query(
        User.username,
        func.count(BookRequest.id).label('borrow_count')
    ).join(BookRequest, BookRequest.user_id == User.id).group_by(User.username).order_by(desc('borrow_count')).limit(5).all()

    labels = [item[0] for item in data]
    values = [item[1] for item in data]

    total_borrowed = sum(values)

    if not data:
        return jsonify({
        'labels': labels,
        'data': values,
        'keyStats': ['Could not compute Statistics. No User has Requested any Books.']
    })
    
    key_stats = [
        f"Total Books Borrowed by Top 5 Users: {total_borrowed}",
        f"Top Borrower: {labels[0]} ({values[0]} books)",
        f"Average Books Borrowed by Top 5 Users: {total_borrowed / 5:.2f}"
    ]

    return jsonify({
        'labels': labels,
        'data': values,
        'keyStats': key_stats
    })

@app.route('/statistics')
def statistics():

    if session['role'] != 'librarian':
        flash('Access forbidden!', 'danger')
        return redirect('/user')

    return render_template('statistics.html')

#-------------------------------------------- Notifications ----------------------------------------------#

def generate_verification_code():
    return ''.join(random.choices(string.ascii_uppercase + string.digits, k=6))

def send_verification_email(user_email, verification_code):
    sender_email = "ed22b041@smail.iitm.ac.in" 
    password = "6RytZ?KD6RQ" 

    subject = "Verify Your Email for Library Notifications"
    body = f"Your verification code is: {verification_code}"

    msg = MIMEMultipart()
    msg['From'] = sender_email
    msg['To'] = user_email
    msg['Subject'] = subject
    msg.attach(MIMEText(body, 'plain'))

    try:
        with smtplib.SMTP('smtp.gmail.com', 587) as server:
            server.starttls()
            server.login(sender_email, password)
            server.sendmail(sender_email, user_email, msg.as_string())
        logger.info(f"Verification email sent to {user_email}")
    except Exception as e:
        logger.error(f"Failed to send email to {user_email}: {str(e)}")
        raise

@app.route('/update_notification_preference', methods=['POST'])
def update_notification_preference():

    if session['role'] != 'user':
        flash('Access forbidden!', 'danger')
        return redirect('/librarian')

    user_id = session.get('user_id')
    if not user_id:
        return jsonify({'status': 'error', 'message': 'User not logged in'}), 401

    user = User.query.get(user_id)
    if not user:
        return jsonify({'status': 'error', 'message': 'User not found'}), 404
    
    user = User.query.get(user_id)
    if not user.email:
        return jsonify({'status': 'error', 'message': 'User Email not found. Please Register your Email in Profile Section to Proceed'}), 404

    data = request.json
    notifications_enabled = data.get('notificationsEnabled', False)
    
    try:
        if notifications_enabled and not user.notifications_enabled:
            verification_code = generate_verification_code()
            user.verification_code = verification_code
            db.session.commit()
            send_verification_email(user.email, verification_code)
            return jsonify({'status': 'verification_required'})
        
        user.notifications_enabled = notifications_enabled
        user.verification_code = None
        db.session.commit()
        return jsonify({'status': 'success'})
    except Exception as e:
        db.session.rollback()
        logger.error(f"Error updating notification preference: {str(e)}")
        return jsonify({'status': 'error', 'message': 'An error occurred'}), 500

@app.route('/verify_email', methods=['POST'])
def verify_email():

    if session['role'] != 'user':
        flash('Access forbidden!', 'danger')
        return redirect('/librarian')
    
    user_id = session.get('user_id')
    if not user_id:
        return jsonify({'status': 'error', 'message': 'User not logged in'}), 401

    user = User.query.get(user_id)
    if not user:
        return jsonify({'status': 'error', 'message': 'User not found'}), 404

    data = request.json
    verification_code = data.get('verificationCode')

    if verification_code == user.verification_code:
        user.notifications_enabled = True
        user.verification_code = None
        db.session.commit()
        return jsonify({'status': 'success'})
    else:
        return jsonify({'status': 'error', 'message': 'Invalid verification code'}), 400

def send_email(to_email, subject, message):
    sender_email = "ed22b041@smail.iitm.ac.in"  
    password = "6RytZ?KD6RQ" 

    msg = MIMEMultipart()
    msg['From'] = sender_email
    msg['To'] = to_email
    msg['Subject'] = subject
    msg.attach(MIMEText(message, 'plain'))

    try:
        with smtplib.SMTP('smtp.gmail.com', 587) as server:
            server.starttls()
            server.login(sender_email, password)
            server.sendmail(sender_email, to_email, msg.as_string())
    except Exception as e:
        logger.error(f"Failed to send email to {to_email}: {str(e)}")

@app.route('/send_reminders', methods=['GET'])
def send_reminders():

    if session['role'] != 'user':
        flash('Access forbidden!', 'danger')
        return redirect('/librarian')

    today = datetime.now().date()
    
    # Check for users who haven't visited in a while
    last_visit_threshold = today - timedelta(days=30)  # Adjust as needed
    users_to_remind = User.query.filter(and_(User.last_visit < last_visit_threshold, User.notifications_enabled == True)).all()

    # Check for books with approaching return dates
    upcoming_return_threshold = today + timedelta(days=3)  # Adjust as needed
    books_to_return = db.session.query(Book, BookRequest.user_id).join(BookRequest).filter(
        and_(
            Book.return_date <= upcoming_return_threshold,
            Book.return_date > today,
            BookRequest.status == 'Approved'
        )
    ).all()

    # Send visit reminders
    for user in users_to_remind:
        message = f"Hello {user.username}, we haven't seen you in a while. Please visit the library soon!"
        send_email(user.email, "Library Visit Reminder", message)

    # Send book return reminders
    for book, user_id in books_to_return:
        user = User.query.get(user_id)
        if user and user.notifications_enabled:
            message = f"Hello {user.username},\n\nYour book '{book.name}' is due on {book.return_date.strftime('%Y-%m-%d')}. Please return it soon."
            send_email(user.email, "Book Return Reminder", message)
    
    return jsonify({'status': 'reminders_sent'})


scheduler = BackgroundScheduler()

# Define the job
def schedule_send_reminders():
    with app.app_context():
        send_reminders()

# Add job to scheduler to run daily at 6 PM
scheduler.add_job(schedule_send_reminders, CronTrigger(hour=18, minute=0, second=0))

# Start the scheduler
scheduler.start()

#---------------------------------------------- Report PDF ----------------------------------------------------#

def get_activity_data():
    today = datetime.now()
    start_of_month = today.replace(day=1, hour=0, minute=0, second=0, microsecond=0)
    start_of_last_month = (start_of_month - timedelta(days=1)).replace(day=1)
    end_of_last_month = today

    # Fetch issued e-books and feedback for the last month
    issued_books = (
        db.session.query(Book)
        .join(BookRequest, Book.id == BookRequest.book_id)
        .filter(BookRequest.status.in_(['Approved', 'User Returned', 'Access Removed', 'Due Date Passed']))
        .filter(Book.date_issued >= start_of_month)
        .filter(Book.date_issued < end_of_last_month)
        .all()
    )
    
    feedbacks = Feedback.query.filter(and_(
        Feedback.date_given >= start_of_month,
        Feedback.date_given < end_of_last_month  # Use < start_of_month to exclude current month
    )).all()
    
    # Fetch other relevant data
    total_issued_books = Book.query.filter(and_(
        Book.date_issued >= start_of_month,
        Book.date_issued < end_of_last_month
    )).count()
    
    total_feedbacks = Feedback.query.filter(and_(
        Feedback.date_given >= start_of_month,
        Feedback.date_given < end_of_last_month
    )).count()
    
    total_requests = BookRequest.query.filter(and_(
        BookRequest.date_requested >= start_of_month,
        BookRequest.date_requested < end_of_last_month
    )).count()

    return {
        'issued_books': issued_books,
        'feedbacks': feedbacks,
        'total_issued_books': total_issued_books,
        'total_feedbacks': total_feedbacks,
        'total_requests': total_requests,
        'start_of_month': start_of_last_month,  
        'end_of_last_month': end_of_last_month  
    }

def generate_pdf_report(activity_data):
    buffer = BytesIO()
    doc = SimpleDocTemplate(buffer, pagesize=letter, rightMargin=72, leftMargin=72, topMargin=72, bottomMargin=18)
    
    # Container for the 'Flowable' objects
    elements = []
    
    # Styles
    styles = getSampleStyleSheet()
    styles.add(ParagraphStyle(name='CenteredTitle', parent=styles['Heading1'], alignment=1))

    start_date = activity_data['start_of_month']
    end_date = activity_data['end_of_last_month']

    report_month = month_name[start_date.month]
    report_year = start_date.year
    title = f"Monthly Activity Report - {report_month} {report_year}"
    
    # Title
    elements.append(Paragraph(title, styles['CenteredTitle']))
    elements.append(Spacer(1, 0.25*inch))

    
    intro_text = f"""
    This report provides a comprehensive overview of the library's activities from {start_date.strftime('%d-%m-%Y')} to {end_date.strftime('%d-%m-%Y')}. 
    It includes details on book issuances, user feedback, and other details of engagement with library resources. 
    This information is helps in understanding the user preferences.
    """

    elements.append(Paragraph(intro_text, styles['Normal']))
    elements.append(Spacer(1, 0.25*inch))
    
    # Summary Table
    summary_data = [
        ['Stats', 'Count'],
        ['Total Issued Books', str(activity_data['total_issued_books'])],
        ['Total Feedbacks', str(activity_data['total_feedbacks'])],
        ['Total Requests', str(activity_data['total_requests'])]
    ]
    summary_table = Table(summary_data, colWidths=[3*inch, 1.5*inch])
    summary_table.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, 0), colors.lightblue),
        ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
        ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
        ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
        ('FONTSIZE', (0, 0), (-1, 0), 14),
        ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
        ('BACKGROUND', (0, 1), (-1, -1), colors.beige),
        ('TEXTCOLOR', (0, 1), (-1, -1), colors.black),
        ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
        ('FONTNAME', (0, 1), (-1, -1), 'Helvetica'),
        ('FONTSIZE', (0, 1), (-1, -1), 12),
        ('TOPPADDING', (0, 1), (-1, -1), 6),
        ('BOTTOMPADDING', (0, 1), (-1, -1), 6),
        ('GRID', (0, 0), (-1, -1), 1, colors.black)
    ]))
    elements.append(summary_table)
    elements.append(Spacer(1, 0.5*inch))
    
    # Issued Books Table
    elements.append(Paragraph("Issued Books", styles['Heading2']))
    elements.append(Spacer(1, 0.15*inch))
    issued_books_data = [['Book Name', 'Author', 'Section', 'Date Issued', 'Return Date']]
    for book in activity_data['issued_books']:
        issued_books_data.append([
            book.name,
            book.author,
            book.section.name,
            book.date_issued.strftime('%Y-%m-%d'),
            book.return_date.strftime('%Y-%m-%d')
        ])
    issued_books_table = Table(issued_books_data, colWidths=[1.2*inch, 1.2*inch, 1*inch, 1*inch, 1*inch])
    issued_books_table.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, 0), colors.grey),
        ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
        ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
        ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
        ('FONTSIZE', (0, 0), (-1, 0), 12),
        ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
        ('BACKGROUND', (0, 1), (-1, -1), colors.beige),
        ('TEXTCOLOR', (0, 1), (-1, -1), colors.black),
        ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
        ('FONTNAME', (0, 1), (-1, -1), 'Helvetica'),
        ('FONTSIZE', (0, 1), (-1, -1), 10),
        ('TOPPADDING', (0, 1), (-1, -1), 6),
        ('BOTTOMPADDING', (0, 1), (-1, -1), 6),
        ('GRID', (0, 0), (-1, -1), 1, colors.black)
    ]))
    elements.append(issued_books_table)
    elements.append(Spacer(1, 0.5*inch))
    
    # Feedbacks Table
    elements.append(Paragraph("Feedbacks", styles['Heading2']))
    elements.append(Spacer(1, 0.15*inch))
    feedbacks_data = [['Book Name', 'Given By', 'Rating', 'Comment']]
    for feedback in activity_data['feedbacks']:
        feedbacks_data.append([
            feedback.book_name,
            feedback.user_name,
            str(feedback.rating),
            feedback.comment
        ])
    feedbacks_table = Table(feedbacks_data, colWidths=[1.5*inch, 1.3*inch, 0.7*inch, 2*inch])
    feedbacks_table.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, 0), colors.grey),
        ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
        ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
        ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
        ('FONTSIZE', (0, 0), (-1, 0), 12),
        ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
        ('BACKGROUND', (0, 1), (-1, -1), colors.beige),
        ('TEXTCOLOR', (0, 1), (-1, -1), colors.black),
        ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
        ('FONTNAME', (0, 1), (-1, -1), 'Helvetica'),
        ('FONTSIZE', (0, 1), (-1, -1), 10),
        ('TOPPADDING', (0, 1), (-1, -1), 6),
        ('BOTTOMPADDING', (0, 1), (-1, -1), 6),
        ('GRID', (0, 0), (-1, -1), 1, colors.black)
    ]))
    elements.append(feedbacks_table)
    
    # Build the PDF
    doc.build(elements)
    buffer.seek(0)
    return buffer.getvalue()

def send_report_email(to_email, subject, message, attachment=None):
    sender_email = "ed22b041@smail.iitm.ac.in"  
    password = "6RytZ?KD6RQ"  

    msg = MIMEMultipart()
    msg['From'] = sender_email
    msg['To'] = to_email
    msg['Subject'] = subject
    msg.attach(MIMEText(message, 'plain'))

    if attachment:
        part = MIMEApplication(attachment, Name="Monthly_Report.pdf")
        part['Content-Disposition'] = 'attachment; filename="Monthly_Report.pdf"'
        msg.attach(part)
    
    try:
        with smtplib.SMTP('smtp.gmail.com', 587) as server:
            server.starttls()
            server.login(sender_email, password)
            server.sendmail(sender_email, to_email, msg.as_string())
            print('Email Report Sent')
    except Exception as e:
        logger.error(f"Failed to send email to {to_email}: {str(e)}")

def create_and_send_report():
    # Generate the PDF report
    activity_data = get_activity_data()
    pdf_report = generate_pdf_report(activity_data)
    
    # Fetch librarian email
    librarian = User.query.filter_by(role='librarian').first()
    if librarian:
      with app.app_context():
          send_email(librarian.email, "Monthly Activity Report", "Please find the attached monthly activity report.", pdf_report)

scheduler = BackgroundScheduler()
scheduler.add_job(create_and_send_report, 'cron', day=1, hour=0)  # Run at midnight on the first day of each month
scheduler.start()


#---------------------------------------------- Export CSV ----------------------------------------------------#

STATUS_ORDER = ["Pending Approval", "Approved", "Rejected", "User Returned", "Access Removed", "Due Date Passed"]

def export_to_csv():

    UserAlias1 = aliased(User)
    UserAlias2 = aliased(User)

    book_requests = db.session.query(
        BookRequest,
        Book,
        UserAlias1,
        UserAlias2
    ).join(
        Book, BookRequest.book_id == Book.id
    ).join(
        UserAlias1, BookRequest.user_id == UserAlias1.id
    ).outerjoin(
        UserAlias2, BookRequest.librarian_id == UserAlias2.id
    ).all()

    csv_output = StringIO()
    csv_writer = csv.writer(csv_output)

    csv_writer.writerow([
        'Book Name', 'Author', 'Section', 'User Name', 'Date Requested', 'Date Issued', 'Return Date', 'Status'
    ])

    # Sort data by status order
    sorted_requests = sorted(book_requests, key=lambda r: STATUS_ORDER.index(r[0].status) if r[0].status in STATUS_ORDER else len(STATUS_ORDER))

    for request, book, user, librarian in sorted_requests:
        book_name = book.name if book else 'N/A'
        author = book.author if book else 'N/A'
        section = book.section.name if book and book.section else 'N/A'
        user_name = user.username if user else 'N/A'
        date_requested = request.date_requested.strftime('%Y-%m-%d %H:%M:%S') if request.date_requested else 'N/A'
        date_issued = book.date_issued.strftime('%Y-%m-%d %H:%M:%S') if book.date_issued else 'N/A'
        return_date = book.return_date.strftime('%Y-%m-%d %H:%M:%S') if book.return_date else 'N/A'
        status = request.status if request.status else 'N/A'

        csv_writer.writerow([
            book_name, author, section, user_name, date_requested, date_issued, return_date, status
        ])

    csv_output.seek(0)
    return Response(
        csv_output,
        mimetype='text/csv',
        headers={'Content-Disposition': 'attachment;filename=book_requests.csv'}
    )

@app.route('/export_csv')
def export_csv():

    if session['role'] != 'librarian':
        flash('Access forbidden!', 'danger')
        return redirect('/user')

    return export_to_csv()

#---------------------------------------------- Payment Portal ----------------------------------------------------#

@app.route('/payment/<int:book_id>', methods=['GET'])
def payment_portal(book_id):

    if session['role'] != 'user':
        flash('Access forbidden!', 'danger')
        return redirect('/librarian')

    book = Book.query.get_or_404(book_id)
    return render_template('payment_portal.html', book=book)

@app.route('/confirm_payment/<int:book_id>', methods=['POST'])
def confirm_payment(book_id):

    if session['role'] != 'user':
        flash('Access forbidden!', 'danger')
        return redirect('/librarian')

    transaction_id = request.form['transaction_id']
    user_id = session.get('user_id')

    if not user_id:
        return redirect('/login')

    book = Book.query.get_or_404(book_id)
    transaction = Transaction(book_id=book_id, user_id=user_id, transaction_id=transaction_id)
    db.session.add(transaction)
    db.session.commit()

    return redirect('/transaction_history')

@app.route('/transaction_history', methods=['GET'])
def transaction_history():

    if session['role'] != 'user':
        flash('Access forbidden!', 'danger')
        return redirect('/librarian')

    user_id = session.get('user_id')
    if not user_id:
        return redirect('/login')

    transactions = Transaction.query.filter_by(user_id=user_id).order_by(desc(Transaction.id)).all()
    return render_template('transaction_history.html', transactions=transactions)

def create_pdf_from_text(text_content):
    buffer = io.BytesIO()
    c = canvas.Canvas(buffer, pagesize=letter)
    width, height = letter
    
    # Set up the font and size
    c.setFont("Helvetica", 12)
    
    # Add text content
    y = height - 40
    for line in text_content.splitlines():
        if y < 40:
            c.showPage()
            c.setFont("Helvetica", 12)
            y = height - 40
        c.drawString(40, y, line)
        y -= 15
    
    c.save()
    buffer.seek(0)
    return buffer.getvalue()

@app.route('/download_book/<int:book_id>', methods=['GET'])
def download_book(book_id):

    if session['role'] != 'user':
        flash('Access forbidden!', 'danger')
        return redirect('/librarian')

    book = Book.query.get(book_id)
    if not book:
        return jsonify({'status': 'error', 'message': 'Book not found'}), 404

    if book.content.endswith('.pdf'):
            return send_file(book.content, as_attachment=True, download_name=book.name + '.pdf')

    else:
        # Create PDF from text content
        pdf_content = create_pdf_from_text(book.content)
        return send_file(BytesIO(pdf_content), as_attachment=True, download_name=book.name + '.pdf', mimetype='application/pdf')

@app.route('/approve_transaction/<transaction_id>')
def approve_transaction(transaction_id):

    if session['role'] != 'librarian':
        flash('Access forbidden!', 'danger')
        return redirect('/user')

    transaction = Transaction.query.get_or_404(transaction_id)

    transaction.status = 'Approved'
    db.session.commit()

    flash('Purchase Successfully Approved!!', 'success')

    return redirect(url_for('librarian_show_book_requests'))


if __name__ == '__main__':
   with app.app_context():
        db.create_all()
        create_librarian()
   app.run(debug=True)